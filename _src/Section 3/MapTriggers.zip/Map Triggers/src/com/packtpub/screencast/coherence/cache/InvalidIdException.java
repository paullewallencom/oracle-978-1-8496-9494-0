package com.packtpub.screencast.coherence.cache;

public class InvalidIdException extends RuntimeException {

	public InvalidIdException(String message)
	{
		super(message);
	}
}
