package com.packtpub.screencast.coherence.cache;

import com.packtpub.screencast.coherence.customers.Customer;
import com.packtpub.screencast.coherence.data.CustomerGenerator;
import com.tangosol.net.AbstractInvocable;
import com.tangosol.net.CacheFactory;
import com.tangosol.net.InvocationService;
import com.tangosol.net.NamedCache;

import java.util.ArrayList;
import java.util.Map;
import java.util.Random;

public class ExtendClient {

	static NamedCache cache = null;

	public static void main(String[] asArgs) throws Throwable {
		cache = CacheFactory.getCache("customers");
		System.out.println("Connected to the cache server.");
		
		Random randomGenerator = new Random();

		CustomerGenerator cg = new CustomerGenerator();
		ArrayList<Customer> customers = (ArrayList<Customer>) cg
				.getCustomers(2000);
		putToCache(customers);
		System.out.println("2000 elements were put into the cache.");

	}

	private static void putToCache(ArrayList<Customer> customers) {

		for (int i = 0; i < customers.size(); i++) {
			cache.put(customers.get(i).getId(), customers.get(i));
		}

	}
}