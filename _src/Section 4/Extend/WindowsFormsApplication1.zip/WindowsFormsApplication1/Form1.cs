﻿using System;
using System.Windows.Forms;
using Tangosol.Net;


namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        INamedCache customerCache = null;
        public Form1(INamedCache cache)
        {
            InitializeComponent();
            customerCache = cache;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Button pressed");
            
            Customer customer = (Customer) customerCache[idTextBox.Text];
            Console.WriteLine("First name of the customer:{0}", customer.getFirstName());

            firstNameTextBox.Text = customer.getFirstName();
            lastNameTextBox.Text = customer.getLastName();
            countryTextBox.Text = customer.getCountry();
            zipCodeTextBox.Text = customer.getZipCode().ToString();
            citizenNoTextBox.Text = customer.getCitizenNo();
            ageTextBox.Text = customer.getAge().ToString();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
