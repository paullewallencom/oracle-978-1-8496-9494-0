﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Tangosol.IO.Pof;

namespace WindowsFormsApplication1
{
    class Customer : IPortableObject
    {


        private string id;
        private string firstName;
        private string lastName;
        private string country;
        private int zipCode;
        private string citizenNo;
        private int age; 

        private const int ID = 0;
        private const int FIRST_NAME = 1;
        private const int LAST_NAME = 2;
        private const int COUNTRY = 3;
        private const int ZIP_CODE = 4;
        private const int CITIZEN_NO = 5;
        private const int AGE = 6;

        public Customer() { }

        public string getId()
        {
            return id;
        }

        public void setId(string id)
        {
            this.id = id;
        }

        public string getFirstName()
        {
            return firstName;
        }

        public void setFirstName(string firstName)
        {
            this.firstName = firstName;
        }

        public string getLastName()
        {
            return lastName;
        }

        public void setLastName(string lastName)
        {
            this.lastName = lastName;
        }

        public string getCountry()
        {
            return country;
        }

        public void setCountry(string country)
        {
            this.country = country;
        }

        public int getZipCode()
        {
            return zipCode;
        }

        public void setZipCode(int zipCode)
        {
            this.zipCode = zipCode;
        }

        public string getCitizenNo()
        {
            return citizenNo;
        }

        public void setCitizenNo(string citizenNo)
        {
            this.citizenNo = citizenNo;
        }

        public int getAge()
        {
            return age;
        }

        public void setAge(int age)
        {
            this.age = age;
        }

        public Customer(string id, string firstName, string lastName,
            string country, int zipCode, string citizenNo, int age)
        {

            this.id = id;
            this.firstName = firstName;
            this.lastName = lastName;
            this.country = country;
            this.zipCode = zipCode;
            this.citizenNo = citizenNo;
            this.age = age;
        }

        public void ReadExternal(IPofReader reader)
        {
            // Reads Customer object from the serialized form

            id = reader.ReadString(ID);
            firstName = reader.ReadString(FIRST_NAME);
            lastName = reader.ReadString(LAST_NAME);
            country = reader.ReadString(COUNTRY);
            zipCode = reader.ReadInt32(ZIP_CODE);
            citizenNo = reader.ReadString(CITIZEN_NO);
            age = reader.ReadInt32(AGE);
        }

        public void WriteExternal(IPofWriter writer)
        {
            // Writes Customer object into the serialized form

            writer.WriteString(ID, this.id);
            writer.WriteString(FIRST_NAME, this.firstName);
            writer.WriteString(LAST_NAME, this.lastName);
            writer.WriteString(COUNTRY, this.country);
            writer.WriteInt32(ZIP_CODE, this.zipCode);
            writer.WriteString(CITIZEN_NO, this.citizenNo);
            writer.WriteInt32(AGE, this.age);
        }
    }
}
	

    

