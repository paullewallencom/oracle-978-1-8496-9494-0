In the C# application, for "cache-config.xml","coherence.xml" and "pof-config.xml" file's "Copy to Output Direct" attributes should be set to true. It means that in the project folder these files will be copied to the bin/Debug folder after the project has been built. 

If you don't want to deal with it, you can copy these 3 configuration files to the same folder with executable file.