How do you install it?

Extract the zip files into a folder. Then click:
File->Import

Then, 

General->Existing Projects into Workspace

Choose "Select root directory" and then click "Browse". Then choose the folder which we extracted in before. Then click "Finish".
